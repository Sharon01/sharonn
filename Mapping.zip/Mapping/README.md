## Neighbourhood Map project for Udacity Nanodegree Program
------------------------------------------------------------

## About the project

NeighbourhoodMap is the neighbour locations of Hyderabad City which are the tourist locations of Hyderabad which show cases the 
locations of that places from google maps and also gets image,review and rating
of that place from Foursquare.

-----------------------------------------------------------------------

## Libraries used
- [knockoutjs](http://knockoutjs.com/).

------------------------------------------------------------
## Api's used
- Google Maps.
- Foursquare.

-------------------------------------------------------------
- Download the zip file and open index.html to run locally

or

-Clone it from github: https://github.com/Sharon01/sharonn
------------------------------------------------------------

The content of this repository is licensed under [MIT License] https://github.com/Sharon01/sharonn/blob/master/License.txt